package com.example.gregoridaniele;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Collections;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    ArrayList<TextView> tvs = new ArrayList<>();
    TextView win, counter;
    int count = 0;
    ArrayList<Integer> numbers;
    int indice_vuoto;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        for (int i = 0; i < 9; i++) {
            String textId = String.format("tv%d", i + 1);
            int id = getResources().getIdentifier(textId, "id", getPackageName());
            tvs.add(findViewById(id));
            Log.d("DEBUG", "" + tvs.size() + "i=" + i);
            tvs.get(i).setOnClickListener(this);
        }

        win = findViewById(R.id.win);
        counter = findViewById(R.id.counter);

        numbers = new ArrayList<>();
        Collections.addAll(numbers, 1, 2, 3, 4, 5, 6, 7, 8);
    }

    @Override
    public void onClick(View view) {
        TextView tv = (TextView) view;

        if (tv.getText().toString().equals("")) {
            return;
        }

        switch (tv.getId()) {
            case R.id.tv1:
                if (checkEmpty(1, 3)) {
                    tvs.get(indice_vuoto).setText(tvs.get(0).getText().toString());
                    tv.setText("");
                    checkWin();
                }
                break;
            case R.id.tv2:
                if (checkEmpty(0, 2, 4)) {
                    tvs.get(indice_vuoto).setText(tvs.get(1).getText().toString());
                    tv.setText("");
                    checkWin();
                }
                break;
            case R.id.tv3:
                if (checkEmpty(1, 5)) {
                    tvs.get(indice_vuoto).setText(tvs.get(2).getText().toString());
                    tv.setText("");
                    checkWin();
                }
                break;
            case R.id.tv4:
                if (checkEmpty(0, 4, 6)) {
                    tvs.get(indice_vuoto).setText(tvs.get(3).getText().toString());
                    tv.setText("");
                    checkWin();
                }
                break;
            case R.id.tv5:
                if (checkEmpty(1, 3, 5, 7)) {
                    tvs.get(indice_vuoto).setText(tvs.get(4).getText().toString());
                    tv.setText("");
                    checkWin();
                }
                break;
            case R.id.tv6:
                if (checkEmpty(2, 4, 8)) {
                    tvs.get(indice_vuoto).setText(tvs.get(5).getText().toString());
                    tv.setText("");
                    checkWin();
                }
                break;
            case R.id.tv7:
                if (checkEmpty(3, 7)) {
                    tvs.get(indice_vuoto).setText(tvs.get(6).getText().toString());
                    tv.setText("");
                    checkWin();
                }
                break;
            case R.id.tv8:
                if (checkEmpty(4, 6, 8)) {
                    tvs.get(indice_vuoto).setText(tvs.get(7).getText().toString());
                    tv.setText("");
                    checkWin();
                }
                break;
            case R.id.tv9:
                if (checkEmpty(5, 7)) {
                    tvs.get(indice_vuoto).setText(tvs.get(8).getText().toString());
                    tv.setText("");
                    checkWin();
                }
                break;
        }
    }

    public void checkWin() {
        count++;
        counter.setText("Spostamenti: " + count);

        if (tvs.get(0).getText().toString().equals("1") &&
                tvs.get(1).getText().toString().equals("2") &&
                tvs.get(2).getText().toString().equals("3") &&
                tvs.get(3).getText().toString().equals("4") &&
                tvs.get(4).getText().toString().equals("5") &&
                tvs.get(5).getText().toString().equals("6") &&
                tvs.get(6).getText().toString().equals("7") &&
                tvs.get(7).getText().toString().equals("8") &&
                tvs.get(8).getText().toString().equals("")) {

            win.setVisibility(View.VISIBLE);
            win.setText("Hai vinto in " + count + " mosse");

        }
    }

    public void resetClick(View view) {
        numbers.clear();
        Collections.addAll(numbers, 8, 7, 6, 5, 4, 3, 2, 1);
        count = 0;
        counter.setText("Spostamenti: 0");
        win.setVisibility(View.INVISIBLE);
        tvs.get(8).setText("");

        int i = 0;

        for (TextView t : tvs) {
            if (i == 8) {
                return;
            }
            t.setText("" + numbers.get(i));
            i++;
        }
    }

    public void resetCasualeClicked(View view) {
        numbers.clear();
        Collections.addAll(numbers, 8, 7, 6, 5, 4, 3, 2, 1);
        Collections.shuffle(numbers);
        count = 0;
        counter.setText("Spostamenti: 0");
        win.setVisibility(View.INVISIBLE);
        tvs.get(8).setText("");

        int i = 0;

        for (TextView t : tvs) {
            if (i == 8) {
                return;
            }
            t.setText("" + numbers.get(i));
            i++;
        }
    }

    public boolean checkEmpty(int... ids) {
        for (int i = 0; i < ids.length; i++) {
            if (tvs.get(ids[i]).getText().toString().equals("")) {
                indice_vuoto = tvs.indexOf(tvs.get(ids[i]));
                return true;
            }
        }
        return false;
    }
}